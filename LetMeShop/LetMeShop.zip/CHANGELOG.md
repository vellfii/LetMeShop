## 1.0.0
- Initial release
## 1.0.1
- Fixed Thunderstore mod icon
## 1.1.0
- Fixed bug that didn't allow usage in multiplayer
- No longer client-side
## 1.1.1
- actually fucking updated it
## 1.1.2
- im so sorry it's updated fr this time